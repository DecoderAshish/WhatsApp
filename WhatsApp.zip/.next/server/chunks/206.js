exports.id = 206;
exports.ids = [206];
exports.modules = {

/***/ 7517:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "en": function() { return /* reexport */ Chat; },
  "NJ": function() { return /* reexport */ Chatscreen; },
  "aN": function() { return /* reexport */ Loader; },
  "v0": function() { return /* reexport */ Message; },
  "Vk": function() { return /* reexport */ NewChat; },
  "YE": function() { return /* reexport */ Sidebar; },
  "ao": function() { return /* reexport */ UserInfo; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/solid/esm/index.js + 230 modules
var esm = __webpack_require__(3802);
// EXTERNAL MODULE: external "react-firebase-hooks/auth"
var auth_ = __webpack_require__(3307);
// EXTERNAL MODULE: external "react-firebase-hooks/firestore"
var firestore_ = __webpack_require__(9030);
// EXTERNAL MODULE: ./firebase.js
var firebase = __webpack_require__(8616);
// EXTERNAL MODULE: external "better-react-spinkit/dist/FoldingCube"
var FoldingCube_ = __webpack_require__(1581);
var FoldingCube_default = /*#__PURE__*/__webpack_require__.n(FoldingCube_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/outline/esm/index.js + 230 modules
var outline_esm = __webpack_require__(6049);
;// CONCATENATED MODULE: ./components/sidebar/index.jsx











const Sidebar = ({
  activeChat
}) => {
  var _chatsSnapshot$docs;

  const [user] = (0,auth_.useAuthState)(firebase/* auth */.I8);
  const userChatRef = firebase.db.collection("chats").where("users", "array-contains", user === null || user === void 0 ? void 0 : user.email);
  const [chatsSnapshot] = (0,firestore_.useCollection)(userChatRef);
  const {
    0: chatQuery,
    1: setChatQuery
  } = (0,external_react_.useState)("");
  const {
    0: theme,
    1: setTheme
  } = (0,external_react_.useState)("light");

  const updateTheme = () => {
    var _localStorage$getItem, _document$querySelect, _document$querySelect2;

    const localTheme = (_localStorage$getItem = localStorage.getItem("theme")) !== null && _localStorage$getItem !== void 0 ? _localStorage$getItem : theme;
    setTheme(localTheme);
    (_document$querySelect = document.querySelector("html")) === null || _document$querySelect === void 0 ? void 0 : _document$querySelect.setAttribute("data-theme", localTheme);
    localTheme === "dark" && ((_document$querySelect2 = document.querySelector("html")) === null || _document$querySelect2 === void 0 ? void 0 : _document$querySelect2.classList.add("dark"));
  };

  const changeTheme = () => {
    var _localStorage$getItem2;

    const localTheme = (_localStorage$getItem2 = localStorage.getItem("theme")) !== null && _localStorage$getItem2 !== void 0 ? _localStorage$getItem2 : localTheme;

    if (theme === "light") {
      var _document$querySelect3, _document$querySelect4;

      (_document$querySelect3 = document.querySelector("html")) === null || _document$querySelect3 === void 0 ? void 0 : _document$querySelect3.setAttribute("data-theme", "dark");
      (_document$querySelect4 = document.querySelector("html")) === null || _document$querySelect4 === void 0 ? void 0 : _document$querySelect4.classList.add("dark");
      localStorage.setItem("theme", "dark");
      setTheme("dark");
    } else {
      var _document$querySelect5, _document$querySelect6;

      (_document$querySelect5 = document.querySelector("html")) === null || _document$querySelect5 === void 0 ? void 0 : _document$querySelect5.setAttribute("data-theme", "light");
      (_document$querySelect6 = document.querySelector("html")) === null || _document$querySelect6 === void 0 ? void 0 : _document$querySelect6.classList.remove("dark");
      localStorage.setItem("theme", "light");
      setTheme("light");
    }
  };

  (0,external_react_.useEffect)(() => {
    updateTheme();
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
    className: "main-container border-r-2 lg:w-80 border-gray-100 dark:border-gray-700 sticky h-screen overflow-y-auto scrollbar-thin scrollbar-thumb-gray-500 scrollbar-track-transparent",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "header bg-base-200 shadow-sm flex sticky top-0 z-10 justify-between items-center p-4 h-20 border-b-2 border-solid dark:border-gray-700",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "dropdown",
        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "border-none btn btn-square btn-lg btn-ghost mask mask-squircle hover:bg-base-100" // onClick={() => auth.signOut()}
          ,
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "avatar online",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "w-12 h-12 rounded-full",
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: user === null || user === void 0 ? void 0 : user.photoURL,
                alt: "User Avatar"
              })
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
          tabIndex: 0,
          className: "p-2 shadow menu dropdown-content bg-base-100 rounded-box w-64",
          children: /*#__PURE__*/jsx_runtime_.jsx("li", {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              onClick: () => firebase/* auth.signOut */.I8.signOut(),
              className: "flex",
              children: [/*#__PURE__*/jsx_runtime_.jsx(outline_esm/* LogoutIcon */.R0g, {
                className: "w-5 h-5 mr-1"
              }), " Log Out"]
            })
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "header__icons",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "dropdown dropdown-end",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            tabIndex: 0,
            className: "btn btn-ghost btn-circle",
            children: /*#__PURE__*/jsx_runtime_.jsx(esm/* DotsVerticalIcon */.AjK, {
              className: "w-6 h-6 text-gray-500 dark:text-gray-100"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
            tabIndex: 0,
            className: "p-2 shadow menu dropdown-content bg-base-100 rounded-box w-64",
            children: /*#__PURE__*/jsx_runtime_.jsx("li", {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                onClick: changeTheme,
                className: "flex",
                children: [theme === "light" ? /*#__PURE__*/jsx_runtime_.jsx(outline_esm/* MoonIcon */.kLh, {
                  className: "w-5 h-5 mr-1"
                }) : /*#__PURE__*/jsx_runtime_.jsx(outline_esm/* SunIcon */.NWY, {
                  className: "w-5 h-5 mr-1"
                }), " ", theme === "light" ? "Dark" : "Light", " mode"]
              })
            })
          })]
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "searchbar flex items-center px-5 pt-1",
      children: [/*#__PURE__*/jsx_runtime_.jsx(esm/* SearchIcon */.W1M, {
        className: "w-5 h-5 text-gray-500 dark:text-gray-100"
      }), /*#__PURE__*/jsx_runtime_.jsx("input", {
        placeholder: "Search for a chat",
        className: "searchbar__input rounded-full input input-ghost",
        value: chatQuery,
        onChange: event => setChatQuery(event.target.value)
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
      href: "#new",
      className: "chatbutton flex justify-center btn btn-primary dark:btn-secondary border-t-2 border-solid m-2",
      children: [/*#__PURE__*/jsx_runtime_.jsx(esm/* AnnotationIcon */.rDX, {
        className: "w-6 h-6 text-gray-100 mr-1"
      }), "Start a new chat"]
    }), chatsSnapshot ? (_chatsSnapshot$docs = chatsSnapshot.docs) === null || _chatsSnapshot$docs === void 0 ? void 0 : _chatsSnapshot$docs.filter(chat => chat.data().users.find(user => user.toLowerCase().includes(chatQuery.toLowerCase()))).map(chat => {
      return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        children: [/*#__PURE__*/jsx_runtime_.jsx(Chat, {
          id: chat.id,
          users: chat.data().users,
          activeChat: activeChat
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "border-t-2 border-gray-100 dark:border-gray-700"
        })]
      }, chat.id);
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex justify-center",
      children: /*#__PURE__*/jsx_runtime_.jsx((FoldingCube_default()), {
        color: "#25D366",
        size: 30
      })
    })]
  });
};


// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "better-react-spinkit"
var external_better_react_spinkit_ = __webpack_require__(7621);
;// CONCATENATED MODULE: ./components/loader/index.jsx





const Loader = () => {
  return /*#__PURE__*/jsx_runtime_.jsx("center", {
    className: "grid place-items-center h-screen",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "loader",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "loader__main mx-auto",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/WhatsApp_Logo.webp",
          alt: "Whatsapp Logo",
          className: "login-container__logo mb-5",
          width: 200,
          height: 200
        }), /*#__PURE__*/jsx_runtime_.jsx(external_better_react_spinkit_.FoldingCube, {
          color: "#25D366",
          size: 60
        })]
      })
    })
  });
};


// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__(8349);
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_);
// EXTERNAL MODULE: ./node_modules/next/dist/client/router.js
var client_router = __webpack_require__(4651);
// EXTERNAL MODULE: ./utils/getRecipientEmail.js
var getRecipientEmail = __webpack_require__(3659);
// EXTERNAL MODULE: external "dayjs/plugin/localizedFormat"
var localizedFormat_ = __webpack_require__(2461);
var localizedFormat_default = /*#__PURE__*/__webpack_require__.n(localizedFormat_);
;// CONCATENATED MODULE: ./components/chat/index.jsx












const Chat = ({
  id,
  users,
  activeChat
}) => {
  var _recipientSnapshot$do, _recipientSnapshot$do2, _messagesSnapshot$doc, _messagesSnapshot$doc2;

  const router = (0,client_router.useRouter)();
  const [user] = (0,auth_.useAuthState)(firebase/* auth */.I8);
  const recipientEmail = (0,getRecipientEmail/* default */.Z)(users, user);
  const [recipientSnapshot] = (0,firestore_.useCollection)(firebase.db.collection("users").where("email", "==", recipientEmail || ""));
  const [messagesSnapshot] = (0,firestore_.useCollection)(firebase.db.collection("chats").doc(id).collection("messages").orderBy("timestamp", "desc"));
  const recipient = recipientSnapshot === null || recipientSnapshot === void 0 ? void 0 : (_recipientSnapshot$do = recipientSnapshot.docs) === null || _recipientSnapshot$do === void 0 ? void 0 : (_recipientSnapshot$do2 = _recipientSnapshot$do[0]) === null || _recipientSnapshot$do2 === void 0 ? void 0 : _recipientSnapshot$do2.data();
  const message = messagesSnapshot === null || messagesSnapshot === void 0 ? void 0 : (_messagesSnapshot$doc = messagesSnapshot.docs) === null || _messagesSnapshot$doc === void 0 ? void 0 : (_messagesSnapshot$doc2 = _messagesSnapshot$doc[0]) === null || _messagesSnapshot$doc2 === void 0 ? void 0 : _messagesSnapshot$doc2.data();

  const enterChat = () => {
    router.push(`/chat/${id}`);
  };

  external_dayjs_default().extend((localizedFormat_default()));
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    onClick: enterChat,
    className: `container flex items-center cursor-pointer break-words p-2 hover:bg-base-200 transition duration-300 ease-in-out${activeChat === id ? " bg-base-200 hover:bg-base-200" : ""}`,
    children: [recipient ? /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "recipient-avatar avatar m-1 mr-4",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-12 h-12 ring ring-primary dark:ring-secondary ring-offset-2 dark:ring-offset-0 rounded-full",
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: recipient === null || recipient === void 0 ? void 0 : recipient.photoURL,
            alt: recipientEmail + "'s" + " Avatar"
          })
        })
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "recipient-avatar avatar placeholder m-1 mr-4",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "bg-neutral text-neutral-content w-12 h-12 ring ring-primary dark:ring-offset-0 dark:ring-secondary ring-offset-2 rounded-full",
        children: /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "text-2xl font-medium",
          children: recipientEmail === null || recipientEmail === void 0 ? void 0 : recipientEmail[0].toUpperCase()
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "grid w-full",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "font-poppins font-medium text-sm md:text-base",
          children: recipient && recipient.username && recipient.username.length ? recipient.username : recipientEmail
        }), message ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "text-sm text-gray-400 flex items-center justify-between",
            children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "flex",
              children: message === null || message === void 0 ? void 0 : message.message
            }), /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "mb-auto",
              children: message !== null && message !== void 0 && message.timestamp ? external_dayjs_default()(message.timestamp.toDate()).format("LT") : "..."
            })]
          })
        }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-sm text-gray-400 flex items-center justify-between",
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "flex",
              children: "This chat is encrypted."
            })
          })
        })]
      })
    })]
  });
};


// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "emoji-mart"
var external_emoji_mart_ = __webpack_require__(4854);
// EXTERNAL MODULE: external "firebase"
var external_firebase_ = __webpack_require__(7005);
var external_firebase_default = /*#__PURE__*/__webpack_require__.n(external_firebase_);
// EXTERNAL MODULE: external "react-timeago"
var external_react_timeago_ = __webpack_require__(6062);
var external_react_timeago_default = /*#__PURE__*/__webpack_require__.n(external_react_timeago_);
;// CONCATENATED MODULE: ./components/chatscreen/index.jsx



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
















function Chatscreen({
  chat,
  messages,
  onHeaderClick
}) {
  var _recipientSnapshot$do, _recipientSnapshot$do2, _recipient$lastSeen, _recipient$lastSeen2;

  const router = (0,router_.useRouter)();
  const [user] = (0,auth_.useAuthState)(firebase/* auth */.I8);
  const {
    0: input,
    1: setInput
  } = (0,external_react_.useState)("");
  const {
    0: emojiPickerOpen,
    1: setEmojiPickerOpen
  } = (0,external_react_.useState)(false);
  const endOfMessagesRef = (0,external_react_.useRef)(null);
  const [recipientSnapshot] = (0,firestore_.useCollection)(firebase.db.collection("users").where("email", "==", (0,getRecipientEmail/* default */.Z)(chat.users, user)));
  const [messagesSnapshot] = (0,firestore_.useCollection)(firebase.db.collection("chats").doc(chat.id).collection("messages").orderBy("timestamp", "asc"));
  const recipient = recipientSnapshot === null || recipientSnapshot === void 0 ? void 0 : (_recipientSnapshot$do = recipientSnapshot.docs) === null || _recipientSnapshot$do === void 0 ? void 0 : (_recipientSnapshot$do2 = _recipientSnapshot$do[0]) === null || _recipientSnapshot$do2 === void 0 ? void 0 : _recipientSnapshot$do2.data();
  const recipientEmail = (0,getRecipientEmail/* default */.Z)(chat.users, user);

  const scrollToBottom = () => {
    endOfMessagesRef.current.scrollIntoView({
      behavior: "smooth",
      block: "end",
      inline: "nearest"
    });
  };

  (0,external_react_.useEffect)(() => {
    scrollToBottom();
  }, [messagesSnapshot]);

  const sendMessage = e => {
    e.preventDefault();
    firebase.db.collection("users").doc(user.uid).set({
      lastSeen: external_firebase_default().firestore.FieldValue.serverTimestamp()
    }, {
      merge: true
    });
    firebase.db.collection("chats").doc(router.query.id).collection("messages").add({
      timestamp: external_firebase_default().firestore.FieldValue.serverTimestamp(),
      user: user.email,
      message: input,
      photoURL: user.photoURL,
      receiverHasRead: false
    });
    setInput("");
    scrollToBottom();
  };

  const showMessages = () => {
    if (messagesSnapshot) {
      var _messagesSnapshot$doc;

      return (_messagesSnapshot$doc = messagesSnapshot.docs) === null || _messagesSnapshot$doc === void 0 ? void 0 : _messagesSnapshot$doc.map(message => {
        var _message$data$timesta;

        return /*#__PURE__*/jsx_runtime_.jsx(Message, {
          user: message.data().user,
          message: _objectSpread(_objectSpread({}, message.data()), {}, {
            timestamp: (_message$data$timesta = message.data().timestamp) === null || _message$data$timesta === void 0 ? void 0 : _message$data$timesta.toDate()
          })
        }, message.id);
      });
    } else {
      return /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex justify-center",
        children: /*#__PURE__*/jsx_runtime_.jsx((FoldingCube_default()), {
          color: "#25D366",
          size: 30
        })
      });
    }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "main-container",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "cursor-pointer header bg-base-200 sticky z-40 top-0 flex items-center p-4 h-20 border-b-2 border-gray-200 dark:border-base-200 shadow-sm",
      children: [recipient ? /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "header__recipient-avatar avatar",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-12 h-12 rounded-full",
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: recipient === null || recipient === void 0 ? void 0 : recipient.photoURL,
            alt: recipientEmail + "'s" + " Avatar"
          })
        })
      }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "header__recipient-avatar avatar placeholder",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "bg-neutral text-neutral-content w-12 h-12 rounded-full",
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "text-2xl",
            children: recipientEmail[0].toUpperCase()
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "header__information ml-2 flex-1",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
          className: "text-xl font-semibold mb-1 font-poppins",
          children: recipient ? recipient.username : recipientEmail
        }), recipientSnapshot ? recipient !== null && recipient !== void 0 && (_recipient$lastSeen = recipient.lastSeen) !== null && _recipient$lastSeen !== void 0 && _recipient$lastSeen.toDate() ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "text-xs text-gray-500 dark:text-gray-300",
          children: ["Last active: ", /*#__PURE__*/jsx_runtime_.jsx((external_react_timeago_default()), {
            date: recipient === null || recipient === void 0 ? void 0 : (_recipient$lastSeen2 = recipient.lastSeen) === null || _recipient$lastSeen2 === void 0 ? void 0 : _recipient$lastSeen2.toDate()
          })]
        }) : /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-xs text-gray-500 dark:text-gray-300",
          children: "Last active: Unavailable"
        }) : "..."]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "header__icons",
        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
          onClick: onHeaderClick,
          className: "btn btn-ghost btn-circle",
          children: /*#__PURE__*/jsx_runtime_.jsx(outline_esm/* UserIcon */.tBG, {
            className: "w-6 h-6 text-gray-500 dark:text-gray-300"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "btn btn-circle btn-ghost",
          type: "button",
          onClick: scrollToBottom,
          children: /*#__PURE__*/jsx_runtime_.jsx(outline_esm/* ArrowDownIcon */.veu, {
            className: "w-6 h-6 text-gray-500 dark:text-gray-300"
          })
        })]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "message-container p-8 min-h-screen px-5 lg:px-20 bg-chatscreen dark:bg-base-200",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "end-to-end-notification p-2 rounded-md mx-auto max-w-lg",
        style: {
          backgroundColor: "#FEF3C5"
        },
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex dark:text-gray-600",
          children: [/*#__PURE__*/jsx_runtime_.jsx(esm/* LockClosedIcon */.khe, {
            className: "w-7 text-gray-500 dark:text-gray-600 mr-1"
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-sm",
            children: "Messages are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Click to learn more."
          })]
        })
      }), showMessages(), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "message-container__end-of-message mt-16 float-left clear-both",
        ref: endOfMessagesRef
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
      className: "input-container grid items-center sticky bottom-0 bg-base-200 z-50 p-2 border-transparent",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "w-full bg-chatscreen border-chatscreen",
        children: emojiPickerOpen && /*#__PURE__*/jsx_runtime_.jsx(external_emoji_mart_.Picker, {
          title: "",
          emoji: "",
          style: {
            zIndex: "10",
            marginBottom: "75px",
            position: "fixed",
            bottom: "0"
          },
          set: "facebook",
          onSelect: emoji => {
            setInput(input + emoji.native);
            setEmojiPickerOpen(false);
          },
          color: "#25D366"
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
        className: "flex",
        children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
          type: "button",
          onClick: () => setEmojiPickerOpen(!emojiPickerOpen),
          className: "btn btn-ghost btn-circle",
          children: /*#__PURE__*/jsx_runtime_.jsx(outline_esm/* EmojiHappyIcon */.OdW, {
            className: "w-6 h-6 text-gray-500"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "text",
          className: "input bg-white dark:bg-base-100 rounded-full flex-1 items-center p-3 sticky mx-2",
          value: input,
          placeholder: "Type a message",
          onChange: e => setInput(e.target.value),
          onFocus: () => setEmojiPickerOpen(false)
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          type: "submit",
          onClick: sendMessage,
          disabled: !input,
          hidden: true,
          children: "Send"
        })]
      })]
    })]
  });
}


// EXTERNAL MODULE: external "dayjs/plugin/relativeTime"
var relativeTime_ = __webpack_require__(2289);
var relativeTime_default = /*#__PURE__*/__webpack_require__.n(relativeTime_);
;// CONCATENATED MODULE: ./components/message/index.jsx







const Message = ({
  user,
  message,
  newDay
}) => {
  const [userLoggedIn] = (0,auth_.useAuthState)(firebase/* auth */.I8);

  const TypeOfMessage = ({
    children
  }) => user === userLoggedIn.email ? /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "message-element px-2 py-1 pb-7 w-max rounded-lg m-3 relative text-right ml-auto bg-chatbubble-primary dark:bg-secondary",
    style: {
      minWidth: "105px"
    },
    children: children
  }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "message-element px-2 py-1 pb-7 w-max rounded-lg m-3 relative text-left bg-base-100 whitespace-nowrap",
    style: {
      minWidth: "105px"
    },
    children: children
  });

  const formatTime = timestamp => {
    return timestamp.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  external_dayjs_default().extend((relativeTime_default()));
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "main-container cursor-default grid",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(TypeOfMessage, {
      children: [message === null || message === void 0 ? void 0 : message.message, " ", /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: `w-full timestamp text-gray-500 dark:text-gray-300 p-2 text-xs absolute bottom-0 break-words ${userLoggedIn.email === user ? "text-right right-0 ml-2" : "text-left left-0 mr-2"}`,
        children: message !== null && message !== void 0 && message.timestamp ? formatTime(message === null || message === void 0 ? void 0 : message.timestamp) : "..."
      })]
    })
  });
};


;// CONCATENATED MODULE: ./components/userinfo/index.jsx










const UserInfo = ({
  chat,
  onCloseButtonClick,
  hidden
}) => {
  var _recipientSnapshot$do, _recipientSnapshot$do2, _recipient$lastSeen, _recipient$lastSeen2;

  const [user] = (0,auth_.useAuthState)(firebase/* auth */.I8);
  const router = (0,router_.useRouter)();
  const recipientEmail = (0,getRecipientEmail/* default */.Z)(chat.users, user);
  const [recipientSnapshot] = (0,firestore_.useCollection)(firebase.db.collection("users").where("email", "==", recipientEmail));
  const recipient = recipientSnapshot === null || recipientSnapshot === void 0 ? void 0 : (_recipientSnapshot$do = recipientSnapshot.docs) === null || _recipientSnapshot$do === void 0 ? void 0 : (_recipientSnapshot$do2 = _recipientSnapshot$do[0]) === null || _recipientSnapshot$do2 === void 0 ? void 0 : _recipientSnapshot$do2.data();

  const removeChat = () => {
    firebase.db.collection("chats").doc(chat.id).delete();
    router.push("/");
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
    className: `main-container h-screen transition duration-300 ease-in-out transform translate-x-full ${hidden ? "hidden" : "translate-x-0"}`,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "header bg-base-200 sticky z-40 top-0 flex items-center p-4 h-20 border-b-2 border-gray-200 dark:border-base-200 shadow-sm",
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        onClick: onCloseButtonClick,
        className: "btn-error btn-sm text-gray-100 btn-circle btn mr-2",
        children: /*#__PURE__*/jsx_runtime_.jsx(outline_esm/* XIcon */.b0D, {
          className: "w-6 h-6"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "font-poppins text-lg font-medium",
        children: "Contact Information"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "info bg-base-100 relative w-full h-screen",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "mt-10 grid justify-center",
        children: [recipient ? /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "info__recipient-avatar avatar z-50 justify-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-20 h-20 ring ring-primary dark:ring-secondary ring-offset-2 dark:ring-offset-0 rounded-full",
            children: /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: recipient === null || recipient === void 0 ? void 0 : recipient.photoURL,
              alt: recipientEmail + "'s" + " Avatar"
            })
          })
        }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "info__recipient-avatar avatar placeholder justify-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "bg-neutral text-neutral-content w-20 h-20 ring ring-primary dark:ring-secondary ring-offset-2 dark:ring-offset-0 rounded-full",
            children: /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-2xl",
              children: recipientEmail[0].toUpperCase()
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-poppins mt-3 text-lg font-medium text-center",
          children: recipient ? recipient.username : recipientEmail
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "text-gray-500 dark:text-gray-300 text-center",
          children: recipientSnapshot ? recipient !== null && recipient !== void 0 && (_recipient$lastSeen = recipient.lastSeen) !== null && _recipient$lastSeen !== void 0 && _recipient$lastSeen.toDate() ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
            className: "text-xs text-gray-500 dark:text-gray-300",
            children: ["Last active: ", /*#__PURE__*/jsx_runtime_.jsx((external_react_timeago_default()), {
              date: recipient === null || recipient === void 0 ? void 0 : (_recipient$lastSeen2 = recipient.lastSeen) === null || _recipient$lastSeen2 === void 0 ? void 0 : _recipient$lastSeen2.toDate()
            })]
          }) : /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "text-xs text-gray-500 dark:text-gray-300",
            children: "Last active: Unavailable"
          }) : "..."
        }), recipient ? recipient.email === "akshit.singla.dps@gmail.com" ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "badge flex cursor-default badge-primary dark:badge-secondary mt-2 tooltip",
          "data-tip": "This is the official account of the developer.",
          children: [/*#__PURE__*/jsx_runtime_.jsx(outline_esm/* CodeIcon */.dNJ, {
            className: "w-4 h-4 mr-1"
          }), " Developer Team"]
        }) : "" : "", /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "danger mt-10 grid justify-center",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
            className: "btn btn-error text-gray-100 rounded-none",
            onClick: removeChat,
            children: [/*#__PURE__*/jsx_runtime_.jsx(outline_esm/* TrashIcon */.XHJ, {
              className: "w-5 h-5 mr-0.5"
            }), " Delete Chat"]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "border-t-2 border-gray-300 dark:border-gray-600 my-5"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "developer",
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "font-poppins text-center font-medium",
            children: "Developer Notes"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
            className: "text-gray-500 dark:text-gray-300 text-center",
            children: ["Version: v0.0.1-alpha", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Build: 1000", /*#__PURE__*/jsx_runtime_.jsx("br", {}), new Date().toLocaleDateString()]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "border-t-2 border-gray-300 dark:border-gray-600 my-5"
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: "flex",
          children: ["Made with ", /*#__PURE__*/jsx_runtime_.jsx(outline_esm/* HeartIcon */.h_8, {
            className: "w-6 h-6 text-error mx-1"
          }), " by", /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "https://aktindo.me",
            rel: "_noreferrer",
            target: "_blank",
            className: "link link-primary dark:link-secondary link-hover ml-1",
            children: "@aktindo"
          })]
        })]
      })
    })]
  });
};


;// CONCATENATED MODULE: ./components/modals/newchat/index.jsx



const NewChat = ({
  onInputChange,
  onInputConfirm
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    id: "new",
    className: "modal",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "modal-box grid justify-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
        children: "Please type the email of the user you'd like to chat with..."
      }), /*#__PURE__*/jsx_runtime_.jsx("input", {
        type: "text",
        className: "input mt-2 input-primary dark:input-secondary input-bordered",
        onChange: onInputChange
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "modal-action",
        children: [/*#__PURE__*/jsx_runtime_.jsx("a", {
          href: "#",
          className: "btn btn-primary dark:btn-secondary",
          onClick: onInputConfirm,
          children: "Submit"
        }), /*#__PURE__*/jsx_runtime_.jsx("a", {
          href: "#",
          className: "btn btn-error",
          children: "Close"
        })]
      })]
    })
  });
};


;// CONCATENATED MODULE: ./components/modals/index.js

;// CONCATENATED MODULE: ./components/index.js








/***/ }),

/***/ 8616:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "db": function() { return /* binding */ db; },
/* harmony export */   "I8": function() { return /* binding */ auth; },
/* harmony export */   "Vv": function() { return /* binding */ googleProvider; }
/* harmony export */ });
/* unused harmony exports rtdb, githubProvider */
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7005);
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_0__);

const firebaseConfig = {
  apiKey: "AIzaSyCa5sYIa8c9r-4Jwj9bzP7qi-ECelsn3vY",
  authDomain: "brosifer11.firebaseapp.com",
  projectId: "brosifer11",
  storageBucket: "brosifer11.appspot.com",
  messagingSenderId: "980519342622",
  appId: "1:980519342622:web:7a07792dda96f4bfae140f"
};
const app = !(firebase__WEBPACK_IMPORTED_MODULE_0___default().apps.length) ? firebase__WEBPACK_IMPORTED_MODULE_0___default().initializeApp(firebaseConfig) : firebase__WEBPACK_IMPORTED_MODULE_0___default().app();
const db = app.firestore();
const auth = app.auth();
const rtdb = firebase__WEBPACK_IMPORTED_MODULE_0___default().database();
const googleProvider = new (firebase__WEBPACK_IMPORTED_MODULE_0___default().auth.GoogleAuthProvider)();
const githubProvider = new (firebase__WEBPACK_IMPORTED_MODULE_0___default().auth.GithubAuthProvider)();


/***/ }),

/***/ 3659:
/***/ (function(__unused_webpack_module, __webpack_exports__) {

"use strict";
const getRecipientEmail = (users, userLoggedIn) => {
  return users === null || users === void 0 ? void 0 : users.filter(userToFilter => userToFilter !== (userLoggedIn === null || userLoggedIn === void 0 ? void 0 : userLoggedIn.email))[0];
};

/* harmony default export */ __webpack_exports__["Z"] = (getRecipientEmail);

/***/ }),

/***/ 4453:
/***/ (function() {

/* (ignored) */

/***/ })

};
;