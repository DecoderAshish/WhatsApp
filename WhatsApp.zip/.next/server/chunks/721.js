exports.id = 721;
exports.ids = [721];
exports.modules = {

/***/ 2721:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var _firebase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8616);






const Login = () => {
  const signInWithGoogle = () => {
    _firebase__WEBPACK_IMPORTED_MODULE_3__/* .auth.signInWithPopup */ .I8.signInWithPopup(_firebase__WEBPACK_IMPORTED_MODULE_3__/* .googleProvider */ .Vv).catch(alert);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
    className: "container grid mx-auto place-items-center mt-10",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
        children: "Login | Whatsapp Clone"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
        rel: "icon",
        href: "/WhatsApp_Logo.webp"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "login-container flex flex-col",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_2__.default, {
        src: "/WhatsApp_Logo.webp",
        alt: "Whatsapp Logo",
        className: "login-container__logo",
        width: 150,
        height: 170
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        onClick: signInWithGoogle,
        className: "btn btn-primary mt-5 login__container__button",
        children: "Login with Google"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
      className: "updates-and-acknowledgement grid text-center w-full max-w-sm mt-8",
      children: ["WhatsApp clone made by me -", " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
        href: "https://decoderashish.me",
        className: "link link-primary dark:link-secondary link-hover",
        target: "_blank",
        children: "@DecoderAshish"
      }), "."]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
      className: "fixed bottom-0 left-0 m-1",
      children: ["\xA9 ", new Date().getFullYear(), " - Decoder Ashish"]
    })]
  });
};

/* harmony default export */ __webpack_exports__["default"] = (Login);

/***/ })

};
;